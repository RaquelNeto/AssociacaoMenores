<!-- Para saber o tipo de post a que pertence echo get_post_format(); -->
 <!-- post_class() para ver quais as classes que são chamadas -->
<article <?php post_class(); ?>>
	<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
	<div class="meta-info">
		<p>Published in <?php echo get_the_date(); ?> by <?php the_author_posts_link(); ?></p>
		<!-- verificar se possui categoria ou não -->
		<?php if( has_category() ):  ?>
			<p>Categories: <?php the_category( ' ' ); ?></p>
		<?php endif; ?>
		<p><?php the_tags( 'Tags: ', ', ' ); ?></p>
	</div>
	<?php the_excerpt(); ?>
</article>